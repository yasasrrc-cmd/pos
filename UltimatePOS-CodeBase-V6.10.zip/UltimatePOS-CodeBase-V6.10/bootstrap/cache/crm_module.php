<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Crm\\Providers\\CrmServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Crm\\Providers\\CrmServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);