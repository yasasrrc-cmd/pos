<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Hms\\Providers\\HmsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Hms\\Providers\\HmsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);